export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - MyShop",
  "siteUrl": "",
  "version": "0.7.13",
  "catchLinks": true
}