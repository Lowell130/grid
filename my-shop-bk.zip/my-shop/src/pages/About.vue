<template>
  <Layout>
    <div class="container">
    <h1>About us</h1>
    <p><i class="fab fa-500px"></i> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error doloremque omnis animi, eligendi magni a voluptatum, vitae, consequuntur rerum illum odit fugit assumenda rem dolores inventore iste reprehenderit maxime! Iusto.</p>
    </div>
  </Layout>
</template>

<script>
export default {
  metaInfo: {
    title: 'About us'
  }
}
</script>


<style lang="scss">
 .container {
  margin-top: 80px;
	
}
</style>